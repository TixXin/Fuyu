# 系统监控

岛上多一个「系统监控」页，收起条上也可以放几个数字。

## 怎么用

- 安装并启用后，岛上会多一个「系统监控」页面：CPU 总占用和五分钟曲线、每个逻辑核心一根小柱、CPU 温度；GPU 占用、温度、显存和功耗（只支持 NVIDIA）；内存；上下行网速和曲线；电池；最占 CPU 或内存的程序（同一程序的进程合在一起，按页面高度最多显示 10 个）。
- 在插件设置里勾选「收起条显示 CPU 占用 / 内存占用 / CPU 温度 / GPU 温度」，收起条上就会出现对应的几列，数值偏高时变黄、变红，点击打开监控页。默认都不勾。
- 页面跟着岛屿的面板大小（设置 → 外观）排版：窄于 600 像素时排成一栏，程序列表在下面；更宽时两栏，程序列表在右边。多出来的高度给图表和程序列表。在插件设置的「监控页排版」里可以固定成两栏或一栏。
- 曲线默认只记页面开着时的数据。勾选「后台记录曲线」后，页面关着时插件也每 5 秒记一次 CPU、GPU 和网速，打开页面就能看到最近一分钟。默认不勾。

## 开销

- 只在需要时读取：监控页打开时每秒一次（程序列表每 3 秒），收起条有勾选项时每 2 秒一次，勾了「后台记录曲线」时页面关着也每秒读一次 CPU、GPU 和网速，都没有时不读。
- 收起条项目和「后台记录曲线」都没勾时，插件在空闲 60 秒后停下，打开页面时再启动；勾了就一直运行（插件卡片上会写原因）。
- 运行时是一个 Windows 自带的 PowerShell 进程，常驻内存约 60–120 MB（大部分是 PowerShell 本身；空进程约 57 MB，开着监控页读数时约 85 MB）。

## 数据来源

都不需要管理员权限，也不联网：

- CPU、每个核心、内存：Windows 性能计数器。
- 网速：网卡的收发字节数。
- 程序：WMI 的 `Win32_Process`（一次查询读完所有进程），两次读取之间的 CPU 时间。
- CPU 温度：WMI 的 ACPI 温度区（`Win32_PerfFormattedData_Counters_ThermalZoneInformation`），取最热的一个。很多台式机主板不提供，会显示 -；这个温度通常是主板测的，比 CPU 核心温度低。
- GPU：`nvidia-smi`，至多每 2 秒一次。没有 NVIDIA 显卡时显示 —。
- 电池：`Win32_Battery`，每 10 秒一次。

## 权限

不需要任何权限。

## 示例演示了什么

自定义界面页面（`webview`）和收起条上的列（`status.update` 的 `cells`，能力 `statusCells`；旧版岛屿只显示文字）。

## 作者

ShengLin1001 在 [TixXin/fly-island#7](https://github.com/TixXin/fly-island/pull/7) 里把系统监控做成了岛屿的内置功能，监控页的版式、样式和收起条的设计都来自那里。TixXin 把它改成了市场插件：读取部分用 PowerShell 重写，收起条改用插件接口 `status.update` 的列。

## English

Designed by ShengLin1001 as a built-in feature in TixXin/fly-island#7; turned into a market plugin by TixXin (data reading rewritten in PowerShell, the bar drawn through `status.update` cells).


Adds a System page: CPU load with five minutes of history, one bar per logical core and the CPU temperature; GPU load, temperature, memory and power (NVIDIA only); memory; download and upload speed; the battery; and the programs using the most CPU or memory (up to ten, as many as the page's height fits). The page follows the island's panel size: one column with the programs below when narrower than 600 px, two columns otherwise; the plugin's "Monitor page layout" setting can fix it to one or two. Tick the plugin's settings to show CPU load, memory, CPU or GPU temperature as small columns on the collapsed bar; they turn yellow and red as they climb.

It reads only while the page is open (every second) or the bar shows figures (every 2 s); with "record the charts in the background" ticked it also reads CPU, GPU and network every 5 s while the page is closed, so the charts show the last minute when it opens. It needs no administrator rights and never goes online. The CPU temperature is the hottest ACPI thermal zone, which many desktops do not have.
