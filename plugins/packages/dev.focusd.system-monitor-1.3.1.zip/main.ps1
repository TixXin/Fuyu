# System monitor (API version 2): CPU, GPU, memory, network, battery and the busiest programs
# on a webview page (ui/), and up to four figures on the collapsed bar (status.update cells).
#
# It reads only while something shows the figures: every second while the page is open
# (programs every 3 s, the GPU every 2 s), every 2 s for the collapsed bar when some bar
# items are ticked, and not at all otherwise. With "record in the background" ticked it also
# reads CPU, GPU and network every 5 s while the page is closed and keeps the last minute,
# which the page gets when it opens. Bar items and background recording keep the plugin running
# (host.keepAlive); without them it starts 10 s after the island and stops when idle.
#
# Sources, all readable without administrator rights: .NET performance counters (CPU, cores,
# memory), the network adapters' byte counts, Win32_Process through WMI (programs), the ACPI thermal zones
# through WMI (CPU temperature; many desktops have none), Win32_Battery, Windows' GPU engine
# counters (any vendor; gpu-engines.ps1) and nvidia-smi (NVIDIA: temperature, power, VRAM).
# This file stays ASCII: Windows PowerShell reads it in the ANSI code page.
. "$PSScriptRoot\lib\focusd.ps1"
. "$PSScriptRoot\gpu-engines.ps1"

$script:Settings = @{}
$script:CanCells = $false
$script:Visible = $false
# The page has loaded and said "ready": samples go to it only then, after the recorded history.
$script:PageReady = $false
$script:Counters = $null
$script:LastNet = $null
$script:LastProcs = $null
$script:Gpu = $null
$script:GpuAt = [datetime]::MinValue
$script:Battery = $null
$script:BatteryAt = [datetime]::MinValue
$script:Thermal = $null
$script:ProcsAt = [datetime]::MinValue
# Program icons, read once each and kept here. The page keeps them only while it is open (its
# saved state is capped at 64 KB), so each is sent once per opening; "ready" lists what it has.
$script:IconCache = @{}
$script:IconsSent = @{}
$script:IconFailed = @{}
$MaxIcons = 200
$script:NextPage = [datetime]::MinValue
$script:NextBar = [datetime]::MinValue
$script:HasSmi = [bool](Get-Command nvidia-smi -ErrorAction SilentlyContinue)
$script:Degree = [string][char]0x00B0
$script:TotalMemory = [double](Get-CimInstance Win32_ComputerSystem -Property TotalPhysicalMemory).TotalPhysicalMemory

$BarKeys = @('barCpu', 'barMemory', 'barCpuTemperature', 'barGpuTemperature')
# The page reads every second. In the background a reading every 5 s is enough for a chart and
# costs a fifth of the CPU; the recording keeps the last minute of them.
$PageMs = 1000
$BackgroundMs = 5000
$HistoryLength = 12
$script:History = @{ cpu = @(); gpu = @(); down = @(); up = @() }
$script:HistoryAt = [datetime]::MinValue

function Test-Setting([string]$Key) {
    $script:Settings.ContainsKey($Key) -and [bool]$script:Settings[$Key]
}

function Test-Bar {
    foreach ($key in $BarKeys) { if (Test-Setting $key) { return $true } }
    $false
}

function Test-Sampling {
    $script:Visible -or (Test-Setting 'backgroundHistory')
}

function Read-Settings($Values) {
    $script:Settings = @{}
    if ($null -ne $Values) {
        foreach ($property in $Values.PSObject.Properties) { $script:Settings[$property.Name] = $property.Value }
    }
    if (Test-Bar) {
        Set-FocusdKeepAlive 'Shows system figures on the collapsed bar'
        $script:NextBar = [datetime]::MinValue
    } else {
        Clear-FocusdStatus 'bar'
        if (Test-Setting 'backgroundHistory') { Set-FocusdKeepAlive 'Records the charts in the background' }
        else { Set-FocusdKeepAlive $null }
    }
}

# Performance counters take a few seconds to open the first time, so only when needed.
function Open-Counters {
    if ($null -ne $script:Counters) { return }
    $names = (New-Object Diagnostics.PerformanceCounterCategory('Processor')).GetInstanceNames() |
        Where-Object { $_ -match '^\d+$' } | Sort-Object { [int]$_ }
    $script:Counters = @{
        Total = New-Object Diagnostics.PerformanceCounter('Processor', '% Processor Time', '_Total')
        Cores = @($names | ForEach-Object { New-Object Diagnostics.PerformanceCounter('Processor', '% Processor Time', $_) })
        Available = New-Object Diagnostics.PerformanceCounter('Memory', 'Available Bytes')
    }
    # A rate counter's first value is always 0; this primes it for the next read.
    [void]$script:Counters.Total.NextValue()
    foreach ($core in $script:Counters.Cores) { [void]$core.NextValue() }
}

function Read-Cpu([bool]$WithCores) {
    $cpu = [math]::Round($script:Counters.Total.NextValue(), 1)
    $cores = @()
    if ($WithCores) { $cores = @($script:Counters.Cores | ForEach-Object { [math]::Round($_.NextValue()) }) }
    @{ cpu = $cpu; cores = $cores }
}

function Read-MemoryUsed {
    # 0.0, not 0: an int first argument makes PowerShell pick Max(Int32, Int32).
    [math]::Max(0.0, $script:TotalMemory - [double]$script:Counters.Available.NextValue())
}

# The hottest ACPI thermal zone in degrees Celsius, or $null (cached for 2 s).
function Read-CpuTemperature {
    if ($null -ne $script:Thermal -and ((Get-Date) - $script:Thermal.At).TotalMilliseconds -lt 1900) { return $script:Thermal.Value }
    $value = $null
    try {
        $zones = @(Get-CimInstance Win32_PerfFormattedData_Counters_ThermalZoneInformation -Property HighPrecisionTemperature -ErrorAction Stop)
        $hottest = ($zones | ForEach-Object { [double]$_.HighPrecisionTemperature } | Measure-Object -Maximum).Maximum
        if ($hottest -gt 0) { $value = [math]::Round($hottest / 10 - 273.15, 1) }
    } catch { }
    $script:Thermal = @{ At = Get-Date; Value = $value }
    $value
}

# The first NVIDIA GPU, at most every 2 s; $null without nvidia-smi.
function Read-Gpu {
    if (-not $script:HasSmi -or ((Get-Date) - $script:GpuAt).TotalMilliseconds -lt 1900) { return $script:Gpu }
    $script:GpuAt = Get-Date
    try {
        $line = @(& nvidia-smi '--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total,power.draw' '--format=csv,noheader,nounits' 2>$null)[0]
        $parts = @($line -split ',\s*')
        $number = { param($text) $parsed = 0.0; if ([double]::TryParse($text, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$parsed)) { $parsed } else { $null } }
        $script:Gpu = if ($parts.Count -ge 6) {
            @{ name = $parts[0]; usage = & $number $parts[1]; temperature = & $number $parts[2]; memoryUsed = & $number $parts[3]; memoryTotal = & $number $parts[4]; power = & $number $parts[5] }
        } else { $null }
    } catch {
        $script:Gpu = $null
    }
    $script:Gpu
}

# Bytes per second down and up across the adapters that are up.
function Read-Network {
    $received = 0L; $sent = 0L
    foreach ($nic in [Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
        if ($nic.OperationalStatus -ne 'Up' -or $nic.NetworkInterfaceType -eq 'Loopback') { continue }
        try { $stats = $nic.GetIPStatistics(); $received += $stats.BytesReceived; $sent += $stats.BytesSent } catch { }
    }
    $now = Get-Date
    $rates = @{ down = 0; up = 0 }
    if ($null -ne $script:LastNet) {
        $seconds = [math]::Max(0.2, ($now - $script:LastNet.At).TotalSeconds)
        $rates.down = [math]::Max(0.0, [math]::Round(($received - $script:LastNet.Received) / $seconds))
        $rates.up = [math]::Max(0.0, [math]::Round(($sent - $script:LastNet.Sent) / $seconds))
    }
    $script:LastNet = @{ At = $now; Received = $received; Sent = $sent }
    $rates
}

function Read-Battery {
    if (((Get-Date) - $script:BatteryAt).TotalSeconds -lt 10) { return $script:Battery }
    $script:BatteryAt = Get-Date
    $battery = @(Get-CimInstance Win32_Battery -Property EstimatedChargeRemaining, BatteryStatus -ErrorAction SilentlyContinue)[0]
    # BatteryStatus 2 means on AC power; 6 to 9 are charging states.
    $script:Battery = if ($null -ne $battery) { @{ percent = [int]$battery.EstimatedChargeRemaining; charging = @(2, 6, 7, 8, 9) -contains [int]$battery.BatteryStatus } } else { $null }
    $script:Battery
}

# A program's icon as a PNG data URL (20 px shown, 32 px read), or $null when its file gives none
# (system processes have no readable path without administrator rights).
function Get-ProgramIcon([string]$Path) {
    if (-not $Path) { return $null }
    try {
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
        $icon = [System.Drawing.Icon]::ExtractAssociatedIcon($Path)
        if ($null -eq $icon) { return $null }
        $bitmap = $icon.ToBitmap()
        $stream = New-Object System.IO.MemoryStream
        $bitmap.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png)
        $data = 'data:image/png;base64,' + [Convert]::ToBase64String($stream.ToArray())
        $stream.Dispose(); $bitmap.Dispose(); $icon.Dispose()
        return $data
    } catch { return $null }
}

# The ten programs using the most CPU and the most memory (the page shows as many as fit), each program's processes added up,
# with the icons of those the page has not got yet. CPU is the share of the whole machine since
# the last scan; $null on the first scan.
function Read-Processes {
    $now = Get-Date
    $times = @{}
    $programs = @{}
    # One WMI query for every process, about 0.1 s. Get-Process opens each process for its CPU
    # time: 2 s and more for a few hundred of them, twice before the page showed anything and
    # then every 3 s, holding up the one-second samples.
    $rows = @(Get-CimInstance Win32_Process -Property ProcessId, Name, KernelModeTime, UserModeTime, WorkingSetSize -ErrorAction SilentlyContinue)
    if ($rows.Count -eq 0) { return $null }
    foreach ($process in $rows) {
        $id = [int]$process.ProcessId
        # 0 is the idle process.
        if ($id -eq 0) { continue }
        $name = [string]$process.Name -replace '\.exe$', ''
        # Both times are in 100 ns.
        $ms = ([double]$process.KernelModeTime + [double]$process.UserModeTime) / 10000
        $times[$id] = $ms
        if (-not $programs.ContainsKey($name)) { $programs[$name] = @{ name = $name; count = 0; cpuMs = 0.0; memory = 0L; id = $id } }
        $entry = $programs[$name]
        $entry.count++
        $entry.memory += [long]$process.WorkingSetSize
        if ($null -ne $script:LastProcs -and $script:LastProcs.Times.ContainsKey($id)) {
            $entry.cpuMs += [math]::Max(0.0, $ms - $script:LastProcs.Times[$id])
        }
    }
    $first = $null -eq $script:LastProcs
    $span = if ($first) { 1 } else { [math]::Max(1, ($now - $script:LastProcs.At).TotalMilliseconds) * [Environment]::ProcessorCount }
    $script:LastProcs = @{ At = $now; Times = $times }
    # CPU needs two scans; take the second one second later rather than three, so the list fills fast.
    if ($first) { $script:ProcsAt = $now.AddMilliseconds(-1900); return $null }
    $list = @($programs.Values | ForEach-Object {
        @{ name = $_.name; count = $_.count; cpu = [math]::Round($_.cpuMs / $span * 100, 1); memory = $_.memory }
    })
    $byCpu = @($list | Sort-Object { $_.cpu } -Descending | Select-Object -First 10)
    $byMemory = @($list | Sort-Object { $_.memory } -Descending | Select-Object -First 10)
    # Paths are read only for the programs shown: reading one costs a handle on the process.
    $icons = @{}
    foreach ($program in @($byCpu) + @($byMemory)) {
        $name = $program.name
        if ($script:IconsSent.ContainsKey($name) -or $script:IconFailed.ContainsKey($name) -or $icons.ContainsKey($name)) { continue }
        if (-not $script:IconCache.ContainsKey($name)) {
            $path = $null
            try { $path = (Get-Process -Id $programs[$name].id -ErrorAction Stop).Path } catch { }
            $icon = Get-ProgramIcon $path
            if ($null -eq $icon) { $script:IconFailed[$name] = $true; continue }
            if ($script:IconCache.Count -ge $MaxIcons) { $script:IconCache.Clear() }
            $script:IconCache[$name] = $icon
        }
        $icons[$name] = $script:IconCache[$name]
        $script:IconsSent[$name] = $true
    }
    @{ byCpu = $byCpu; byMemory = $byMemory; icons = $icons }
}

function Get-Tone([object]$Value, [double]$Warm, [double]$Hot) {
    if ($null -eq $Value) { return 'neutral' }
    if ($Value -ge $Hot) { return 'danger' }
    if ($Value -ge $Warm) { return 'warning' }
    'neutral'
}

function Send-Bar {
    $cpu = $null; $memory = $null; $cpuTemperature = $null; $gpuTemperature = $null
    if ((Test-Setting 'barCpu') -or (Test-Setting 'barMemory')) {
        if (Test-Setting 'barCpu') { $cpu = (Read-Cpu $false).cpu }
        if (Test-Setting 'barMemory') { $memory = [math]::Round((Read-MemoryUsed) / $script:TotalMemory * 100) }
    }
    if (Test-Setting 'barCpuTemperature') { $cpuTemperature = Read-CpuTemperature }
    if (Test-Setting 'barGpuTemperature') { $gpu = Read-Gpu; if ($null -ne $gpu) { $gpuTemperature = $gpu.temperature } }
    $degrees = { param($value) if ($null -eq $value) { '-' } else { "$([math]::Round($value))$script:Degree" } }
    $cells = @()
    if (Test-Setting 'barCpu') { $cells += @{ label = 'CPU'; value = "$([math]::Round($cpu))%"; tone = Get-Tone $cpu 70 90 } }
    if (Test-Setting 'barMemory') { $cells += @{ label = 'RAM'; value = "$memory%"; tone = Get-Tone $memory 80 92 } }
    if (Test-Setting 'barCpuTemperature') { $cells += @{ label = 'CPU'; value = & $degrees $cpuTemperature; tone = Get-Tone $cpuTemperature 75 90 } }
    if (Test-Setting 'barGpuTemperature') { $cells += @{ label = 'GPU'; value = & $degrees $gpuTemperature; tone = Get-Tone $gpuTemperature 75 87 } }
    $text = (@($cells | ForEach-Object { "$($_.label) $($_.value)" }) -join ' ')
    if ($text.Length -gt 24) { $text = $text.Substring(0, 24).TrimEnd() }
    $worst = 'neutral'
    foreach ($cell in $cells) { if ($cell.tone -eq 'danger' -or ($cell.tone -eq 'warning' -and $worst -eq 'neutral')) { $worst = $cell.tone } }
    if ($script:CanCells) { Update-FocusdStatus 'bar' $text -Cells $cells }
    else { Update-FocusdStatus 'bar' $text -Tone $worst }
}

# The four charted series, the same values the page pushes (GPU 0 when there is none), one
# point per 5 s also while the page is open, so the recording stays continuous across openings.
function Add-History([double]$Cpu, $Gpu, $Network) {
    $now = Get-Date
    if (($now - $script:HistoryAt).TotalMilliseconds -lt ($BackgroundMs - 100)) { return }
    $script:HistoryAt = $now
    $usage = 0.0
    if ($null -ne $Gpu -and $null -ne $Gpu.usage) { $usage = $Gpu.usage }
    $new = @{ cpu = $Cpu; gpu = $usage; down = $Network.down; up = $Network.up }
    foreach ($key in $new.Keys) {
        $values = @($script:History[$key]) + $new[$key]
        if ($values.Count -gt $HistoryLength) { $values = $values[($values.Count - $HistoryLength)..($values.Count - 1)] }
        $script:History[$key] = $values
    }
}

# The recording for the page, each 5 s point repeated so the chart keeps one point a second.
function Get-HistoryMessage {
    $repeat = [int]($BackgroundMs / $PageMs)
    $message = @{ type = 'history' }
    foreach ($key in $script:History.Keys) {
        $message[$key] = @(foreach ($value in $script:History[$key]) { for ($i = 0; $i -lt $repeat; $i++) { $value } })
    }
    $message
}

# Background recording with the page closed: only what the charts draw.
function Save-Sample {
    Add-History (Read-Cpu $false).cpu (Read-HistoryGpu) (Read-Network)
}

# The GPU for the page: nvidia-smi where there is one (name, temperature, power, VRAM), Windows'
# engine counters for the load of any GPU and its engines. $null when neither has anything.
function Read-PageGpu {
    $smi = Read-Gpu
    $engines = Read-GpuEngines -Want
    if ($null -eq $smi -and $null -eq $engines) { return $null }
    $gpu = @{ name = $null; usage = $null; temperature = $null; memoryUsed = $null; memoryTotal = $null; power = $null; engines = @() }
    if ($null -ne $engines) {
        $gpu.name = $engines.name; $gpu.usage = $engines.usage; $gpu.memoryUsed = $engines.memoryUsed; $gpu.engines = $engines.engines
    }
    if ($null -ne $smi) {
        foreach ($key in 'name', 'temperature', 'memoryUsed', 'memoryTotal', 'power') { if ($null -ne $smi[$key]) { $gpu[$key] = $smi[$key] } }
        # Task Manager's figure (the busiest engine, video encoding too) where the counters have it.
        if ($null -eq $gpu.usage) { $gpu.usage = $smi.usage }
    }
    $gpu
}

# Background recording: the GPU load without starting the engine reader just for the chart.
function Read-HistoryGpu {
    $engines = Read-GpuEngines
    if ($null -ne $engines) { return @{ usage = $engines.usage } }
    Read-Gpu
}

function Send-Page {
    $now = Get-Date
    $cpu = Read-Cpu $true
    $sample = @{
        type = 'sample'
        cpu = $cpu.cpu
        cores = $cpu.cores
        memoryUsed = Read-MemoryUsed
        memoryTotal = $script:TotalMemory
        cpuTemperature = Read-CpuTemperature
        gpu = Read-PageGpu
        battery = Read-Battery
        # The page lays itself out in one or two columns by this setting.
        layout = [string]$script:Settings['layout']
    }
    $network = Read-Network
    $sample.download = $network.down
    $sample.upload = $network.up
    Add-History $sample.cpu $sample.gpu $network
    if (($now - $script:ProcsAt).TotalMilliseconds -ge 2900) {
        $script:ProcsAt = $now
        $processes = Read-Processes
        if ($null -ne $processes) { $sample.processes = $processes }
    }
    if (-not (Send-FocusdWebviewMessage 'monitor' $sample)) { $script:Visible = $false }
}

function Invoke-Due {
    $now = Get-Date
    if ((Test-Sampling) -and $now -ge $script:NextPage) {
        $script:NextPage = $now.AddMilliseconds($(if ($script:Visible) { $PageMs } else { $BackgroundMs }))
        Open-Counters
        if ($script:Visible -and $script:PageReady) { Send-Page } else { Save-Sample }
    }
    if ((Test-Bar) -and $now -ge $script:NextBar) {
        $script:NextBar = $now.AddMilliseconds(2000)
        Open-Counters
        Send-Bar
    }
}

function Get-WaitMs {
    $due = @()
    if (Test-Sampling) { $due += $script:NextPage }
    if (Test-Bar) { $due += $script:NextBar }
    if ($due.Count -eq 0) { return 60000 }
    $next = ($due | Measure-Object -Minimum).Minimum
    [int][math]::Min(60000, [math]::Max(10, ($next - (Get-Date)).TotalMilliseconds))
}

while ($true) {
    $message = Receive-FocusdNotification (Get-WaitMs)
    try {
        if ($null -ne $message) {
            switch ($message.method) {
                'initialize' {
                    $script:CanCells = @($message.params.capabilities) -contains 'statusCells'
                    if (-not (@($message.params.capabilities) -contains 'webview')) {
                        Write-FocusdLog 'this FocuSD Island is too old for this plugin (needs webview pages)'
                    }
                    Read-Settings $message.params.settings
                }
                'settings.changed' { Read-Settings $message.params.settings }
                'view.visible' {
                    $script:Visible = [bool]$message.params.visible
                    if (-not $script:Visible) { $script:PageReady = $false }
                    if (-not $script:Visible) {
                        # Background recording goes on reading the network, so its byte counts stay the baseline.
                        if (-not (Test-Setting 'backgroundHistory')) { $script:LastNet = $null }
                        $script:LastProcs = $null; $script:ProcsAt = [datetime]::MinValue
                    }
                }
                'webview.message' {
                    # The page sends { type: "ready" } once it has loaded; answer at once,
                    # first with the minute recorded while it was closed.
                    if ($message.params.message.type -eq 'ready') {
                        $script:Visible = $true; $script:PageReady = $true; $script:NextPage = [datetime]::MinValue
                        # A page opened afresh may have lost its icons; send what it does not list.
                        $script:IconsSent = @{}
                        foreach ($name in @($message.params.message.icons)) { if ($name) { $script:IconsSent[[string]$name] = $true } }
                        $script:ProcsAt = [datetime]::MinValue
                        if (Test-Setting 'backgroundHistory') { [void](Send-FocusdWebviewMessage 'monitor' (Get-HistoryMessage)) }
                    }
                    # The page's button next to the program list.
                    if ($message.params.message.type -eq 'taskManager') {
                        try { Start-Process taskmgr.exe } catch { Write-FocusdLog "could not open Task Manager: $($_.Exception.Message)" }
                    }
                }
                'shutdown' { exit 0 }
            }
        }
        Invoke-Due
    } catch {
        # Keep running: one failed read should not make the island restart the plugin.
        Write-FocusdLog "error: $($_.Exception.Message)"
    }
}
